Entity Systems
============
Nez no longer packages its own entity systems because "the nez ECS was always optional, and it was Shitty AF™️"

If you want to use a full ECS implementation look for:

- [Flecs#](https://github.com/flecs-hub/FlecsSharp)
- [DefaultECS](https://github.com/Doraku/DefaultEcs)
