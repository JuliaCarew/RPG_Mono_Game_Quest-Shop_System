Samples 例子
==========

[Nez实例代码仓库](https://github.com/prime31/Nez-Samples)包含很多具体演示了不同的 Nez 子系统是如何工作的小例子. 为了让它们正常运行你需要:

- clone 仓库, 确保 submodule 也 clone 完整了
- 打开 Nez/Nez.sln 然后构建. 这是需要的以便 NuGet 包被下载
- 现在你可以打开主解决方案然后运行任何一个例子项目了