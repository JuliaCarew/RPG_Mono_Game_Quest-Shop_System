Entity 系统
============
Nez 不会再打包自己的一套 Entity 系统了, 因为 "Nez的ECS往往都是可选的, 并且也是很糟糕的"

如果你想使用一个完整的 ECS 架构的实现请见:

- [Flecs#](https://github.com/flecs-hub/FlecsSharp)
- [DefaultECS](https://github.com/Doraku/DefaultEcs)
