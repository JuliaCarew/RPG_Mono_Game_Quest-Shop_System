﻿
using var game = new MonoGame.Game1();
game.Run();
